## Ported to ROS2 version of csm.

For more information about the C(anonical) Scan Matcher, see the webpage: http://purl.org/censi/2007/csm.

Note: there are two branches on the repository. The "master" branch uses GSL.

This is the ``csm_eigen`` branch, which uses the ``eigen`` library. 
This branch is the work of people working at U. Freiburg and Kuka, 
including [Christoph Sprunk](http://www.informatik.uni-freiburg.de/~sprunkc/) 
and [Rainer Kuemmerle](http://www.informatik.uni-freiburg.de/~kuemmerl/).
